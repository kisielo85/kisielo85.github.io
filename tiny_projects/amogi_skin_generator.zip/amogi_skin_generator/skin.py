from PIL import Image
import colorsys
import os

def hex_to_rgb(hex_str):
    if hex_str.startswith('#'):
        hex_str = hex_str[1:]
    
    if len(hex_str)==3:
        hex_str=hex_str[0]*2+hex_str[1]*2+hex_str[2]*2
        
    try:
        if len(hex_str)!=6:
            raise Exception
        
        return tuple([int(hex_str[i:i + 2], 16) for i in range(0, len(hex_str), 2)])
    except:
        print("invalid hex code")
        return [-1,-1,-1]

img = Image.open("original.png")
original=img.convert('RGBA').load()


# output folder
if not os.path.isdir("amogi"):
  os.mkdir("amogi")

while (True):
    color=input("hex color:").upper()
    r,g,b=hex_to_rgb(color)
    if r==-1: continue
    hue,satr,value=colorsys.rgb_to_hsv(r,g,b)
    

    # tuning hsv to match the original.png colors
    satr-=0.8846
    value-=182

    e = img.convert('RGBA')
    pixels = e.load()

    for x in range(64):
        for y in range(64):

            # skipping transparent pixels
            if pixels[x,y][3]==0: continue

            r,g,b,a=pixels[x,y]
            h,s,v=colorsys.rgb_to_hsv(r,g,b)

            h+=hue
            if h>1: h-=1
            v+=value
            s+=satr
            
            r,g,b=colorsys.hsv_to_rgb(h,s,v)
            pixels[x,y]=(int(r),int(g),int(b),a)

    # keeping the original visor colors
    for x in range(41,47):
        for y in range(11,14):
            pixels[x,y]=original[x,y]

    e.save("amogi/amogi_"+color+".png")
    #e.show()